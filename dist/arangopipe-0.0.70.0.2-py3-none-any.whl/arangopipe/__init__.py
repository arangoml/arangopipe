# __init__.py

# Version of the arangopipe package
__version__ = "0.0.70.0.0"
