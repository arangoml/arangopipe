'use strict';
const db = require('@arangodb').db;
const collectionName = 'aisisInstances';
const users = "users";
const sessions = "sessions";

if (!db._collection(collectionName)) {
  db._createDocumentCollection(collectionName);
}

if (!db._collection(users)) {
  db._createDocumentCollection(users);
}

if (!db._collection(sessions)) {
  db._createDocumentCollection(sessions);
}

// db.collectionName('users').ensureIndex({
//   type: "hash",
//   unique: true,
//   fields: ["username"]
// })
const queues = require('@arangodb/foxx/queues');
const queue = queues.create('expirationQueue');

// Creates the expire job to check if databases should be expired and dropped.
queue.push(
  {mount: '/createDB', name: 'expire'},
  {},
  {
    repeatTimes: Infinity,
    repeatUntil: -1,
    repeatDelay: 30000 // (24 * 60 * 60 * 1000) // Daily
  }
);
